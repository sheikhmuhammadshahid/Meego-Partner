## 2.1.1

- Use automatic plugin registration
- update SDK to >=1.20.0

## 2.1.0

- add toMap to models

## 2.0.0

- device_info_plus_platform_interface upgrade to 2.0.0

## 1.0.1

- Improve documentation

## 1.0.0

- Initial null-safe release.
