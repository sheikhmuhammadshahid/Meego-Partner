# Device Info Plus Windows

[![Flutter Community: device_info_plus_windows](https://fluttercommunity.dev/_github/header/device_info_plus_windows)](https://github.com/fluttercommunity/community)

[![pub package](https://img.shields.io/pub/v/device_info_plus_windows.svg)](https://pub.dev/packages/device_info_plus_windows)

The Windows implementation of [`device_info_plus`](https://pub.dev/packages/device_info_plus).

## Usage

This package is already included as part of the `device_info_plus` package dependency, and will
be included when using `device_info_plus` as normal.
