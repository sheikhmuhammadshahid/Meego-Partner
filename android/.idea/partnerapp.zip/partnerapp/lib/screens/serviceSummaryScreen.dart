import 'package:app/models/bookingDetailModel.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:flutter/material.dart';
class ServiceSummaryScreen extends StatefulWidget {
  const ServiceSummaryScreen(BookingDetail bookingDetail, {Key key, FirebaseAnalytics a, FirebaseAnalyticsObserver o}) : super(key: key);

  @override
  State<ServiceSummaryScreen> createState() => _ServiceSummaryScreenState();
}

class _ServiceSummaryScreenState extends State<ServiceSummaryScreen> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
